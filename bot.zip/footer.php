		<div class="modal fade" id="panelSettings" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<form action="" method="POST">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<ul class="nav nav-tabs">
								<li class="active"><a href="#panel_settings" data-toggle="tab">Database Maintenance</a></li>

							</ul>
						</div>
						<div class="modal-body tabs">

			
							<div class="tab-content">
								<div class="tab-pane fade in active" id="panel_settings">
									<h4>Database Maintenance</h4>
									<hr>
									<div id="dbMessages"></div>
									<button type="button" class="btn btn-primary" onClick="clearAllBots();">Clear Bots Table</button>
									<button type="button" class="btn btn-primary" onClick="clearAllTasks();">Clear Tasks Table</button>
								</div>
							</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						</div>
					</div>
				</div>
				</div>
			</form>
		</div>
		
		<script src="assets/js/bootstrap.min.js"></script>
		<script src="assets/js/chart.min.js"></script>
		<script src="assets/js/chart-data.js"></script>
		<script src="assets/js/easypiechart.js"></script>
		<script src="assets/js/easypiechart-data.js"></script>
		<script src="assets/js/bootstrap-datepicker.js"></script>
		<script src="assets/js/bootstrap-table.js"></script>