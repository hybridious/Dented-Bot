<?php 
$connection = mysqli_connect('localhost', 'root', 'root', 'db');
if (!$connection) {
  die("Database Connection Failed" . mysqli_error($connection));
}
// key has to be same as in C++
$keyz = '8417a031bdadfb493a827cfec74bba14';
?>