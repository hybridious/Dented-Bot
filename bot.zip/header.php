	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Dented Bot</title>

		<link href="assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="assets/css/datepicker3.css" rel="stylesheet">
		<link href="assets/css/styles.css" rel="stylesheet">
		<link href="assets/css/application.css" rel="stylesheet">
		
		<script src="assets/maps/jquery-1.8.2.min.js"></script>
		<script src="assets/js/bots.js"></script>
		<!--Icons-->
		<script src="assets/js/lumino.glyphs.js"></script>

		<!--[if lt IE 9]>
		<script src="js/html5shiv.js"></script>
		<script src="js/respond.min.js"></script>
		<![endif]-->
		</head>